"Hola Algoritmos y Programación I"

# 5) se debe usar la funcion print() para mostrar el mensaje. El mensaje se muestra en 1.1 porque se ejecuta desde el interprete
# mientras que el 1.2 se ejecuta desde la terminal.